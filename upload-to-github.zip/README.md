# Smart Flashcard — Android build guide

A personal, empty-by-default spaced-repetition flashcard app for Android, built
with Capacitor (real native shell around a local-first web app — this is a
real installable `.apk`, not just a website).

Made by **Ali Mohammad Mahdi** — College of Medicine, University of Kufa.

---

## What's already built

Everything in `www/` is the finished, working app:

- `index.html` — all screens (Home, Add, Review, Cards, Statistics, Settings/About) + animated splash
- `css/styles.css` — full design system (light + dark mode, navy/medical-blue/soft-purple palette, difficulty colors)
- `js/db.js` — IndexedDB storage (decks, cards, review history, settings). **Starts completely empty — no seed data.**
- `js/srs.js` — the adaptive spaced-repetition scheduler (SM-2-inspired, independent per-card history)
- `js/notifications.js` — schedules real Android notifications through `@capacitor/local-notifications`
- `js/app.js` — the app controller (routing, review sessions, statistics, settings)

I can't compile/sign an `.apk` binary from inside this chat (no Android SDK,
no network access to fetch Gradle/Capacitor dependencies here), so the last
mile — turning this source into an installed app on your phone — happens on
your machine with Android Studio. It's about 15–20 minutes the first time.

---

## Prerequisites (one-time)

1. **Node.js** (v18+) — https://nodejs.org
2. **Android Studio** — https://developer.android.com/studio (installs the Android SDK for you)
3. A phone with **USB debugging** enabled, or just build an APK file and copy it over.

---

## Build steps

```bash
# 1. Unzip the project, then inside the folder:
npm install

# 2. Add the native Android project (creates an /android folder)
npx cap add android

# 3. Copy the web app into the native project
npx cap sync android

# 4. Open it in Android Studio
npx cap open android
```

Android Studio will open the `android/` project. Then:

1. Let Gradle finish syncing (first time takes a few minutes — it downloads
   the Android build tools).
2. Plug in your phone (USB debugging on) **or** use an emulator.
3. Click the green ▶ **Run** button — this installs a debug build directly
   onto your device. This is a real APK, just unsigned/debug.

### To get a shareable `.apk` file instead of running from Studio:

In Android Studio: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
The generated file appears under `android/app/build/outputs/apk/debug/app-debug.apk`
— copy that to your phone and install it directly (enable "install unknown
apps" for your file manager first).

### For a signed release build (optional, needed for Play Store):

**Build → Generate Signed Bundle / APK**, then follow Android Studio's wizard
to create a keystore. Keep that keystore file safe — you'll need it for every
future update.

---

## App icon & splash image

Source vector art is in `assets-source/icon.svg` and `assets-source/splash.svg`
(navy → medical blue → soft purple gradient with the flashcard/neural motif
described in the brief). To generate every Android density automatically:

```bash
npm install -g @capacitor/assets
npx capacitor-assets generate --android
```

This fills in the launcher icon (including the adaptive icon) and the native
splash background. The animated "Made by Ali Mohammad Mahdi / College of
Medicine / University of Kufa" sequence you see at launch is rendered by the
web layer itself (`#splash` in `index.html`) right after the native splash —
that's intentional, since fine-grained sequenced text animation isn't
something the native splash API supports.

---

## Notifications — how they work, and one honest limitation

`js/notifications.js` schedules a real local notification (via
`@capacitor/local-notifications`) for the exact timestamp each card is next
due, every time you save or rate a card. Tapping a notification opens the
app straight to the Review screen.

Native local notifications can't dynamically query your database at the
moment they fire — their text is fixed when they're scheduled. So instead of
a perfectly live count, each notification says "N card(s) ready for review"
based on what's due *at scheduling time*. In practice this reads naturally
almost all the time; the only edge case is several cards becoming due at
exactly the same moment from different scheduling events, which can produce
back-to-back notifications instead of one merged one. A perfect live digest
would need a background sync job (WorkManager), which is a reasonable
follow-up if you want it.

Everything else — scheduling logic, due-date calculation, offline storage,
review flow — has no such limitation; it's fully real and fully offline.

---

## What starts empty (as required)

No decks, cards, tags, or statistics are ever inserted anywhere in the code.
`db.js` only creates empty IndexedDB object stores. The very first screen you
see after the splash is the "Your Memory System Is Empty" state with a single
**+ ADD INFORMATION** action — everything else is built from what you enter.

## Data & privacy

All data lives in the device's local IndexedDB. Nothing is sent to any
server — the "Quick Add" helper is a local text-reformatting heuristic, not
an external AI call, so it works fully offline and never uploads your notes.
Export/Import (Settings → Data) lets you back up or move your data as a
plain JSON file whenever you choose to.

---

## Project structure

```
flashcard-app/
├── package.json
├── capacitor.config.json
├── assets-source/
│   ├── icon.svg
│   └── splash.svg
└── www/
    ├── index.html
    ├── css/styles.css
    └── js/
        ├── db.js
        ├── srs.js
        ├── notifications.js
        └── app.js
```
